# DonutClient — Forge 1.21.11 / 61.2.5

Independent client-side utility mod for Java 21. This is not the original LarpClient source.

## Implemented catalog entries in v0.6.0 (19/176)

- Fullbright (`G`) with restoration of the previous gamma.
- Zoom (`Z`) with restoration of the previous FOV.
- Auto Sprint while forward is held, when not crouching/passenger and with sufficient hunger.
- AutoEat: uses food already held in the main hand or offhand when hunger is low. It does not search or rearrange inventory.
- AutoTool: selects the fastest suitable tool already in the hotbar for the block being targeted.
- Custom center crosshair.
- Custom FOV toggle (100 degrees; restores the previous setting when disabled).
- Performance HUD: client FPS, server ping when connected, and average worn-armor durability.
- Target HUD: name and health of the entity under the crosshair.
- Looked-at entity label.
- HUD coordinates and dimension.
- Target block name/coordinates and block/sky light display.
- Local waypoints (`K` saves; `L` clears).
- Periodic scan of already-loaded nearby chunks for heuristic SusChunkFinder/Base Finder clues, storage blocks and spawners.
- Motion Scanner heuristic label.
- Config persistence for implemented module toggles.

## Keybinds

| Key | Action |
|---|---|
| Right Shift | Open ClickGUI |
| G | Toggle Fullbright |
| Z | Toggle Zoom |
| K | Save waypoint |
| L | Clear waypoints |

Other implemented modules are toggled in ClickGUI.

## Limitations and safety

- **19 of 176 catalog entries are marked implemented.** Some are basic informational implementations, not complete equivalents of similarly named commercial modules.
- Chunk scanning examines only chunks already loaded by the client, in a small radius and vertical band. It does not load chunks or reveal unloaded terrain.
- Base/SusChunk/Motion findings are heuristics, not proof of a base or player activity.
- StorageESP/SpawnerFinder currently provide scan counts/findings, not world-space 3D boxes.
- Freecam, Freelook, and 3D ESP boxes are not implemented.
- Most Combat, Movement, Player automation, Cosmetics and DonutSMP modules remain planned.
- No anti-cheat bypasses, packet spoofing, combat automation, or server-side exploits are included.
- **Not compiled or tested against Forge 61.2.5 in this environment.** Gradle is not installed in this runtime, so API compatibility and in-game behavior still require a local `gradle build` and client launch using JDK 21.
