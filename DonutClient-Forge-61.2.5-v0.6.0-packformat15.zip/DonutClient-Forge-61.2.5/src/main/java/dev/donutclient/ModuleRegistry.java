package dev.donutclient;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import net.minecraftforge.fml.loading.FMLPaths;

import java.io.Reader;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public final class ModuleRegistry {
    private static final List<ClientModule> MODULES = new ArrayList<>();
    private static final Gson GSON = new Gson();
    private static final Type LIST_TYPE = new TypeToken<List<Map<String, Object>>>() {}.getType();

    private ModuleRegistry() {}

    public static void loadCatalog() {
        try (Reader reader = ModuleRegistry.class.getResourceAsStream("/modules.json") == null
                ? null : new java.io.InputStreamReader(ModuleRegistry.class.getResourceAsStream("/modules.json"))) {
            if (reader == null) throw new IllegalStateException("Missing modules.json");
            List<Map<String, Object>> rows = GSON.fromJson(reader, LIST_TYPE);
            for (Map<String, Object> row : rows) {
                String id = String.valueOf(row.get("id"));
                String name = String.valueOf(row.get("name"));
                String category = String.valueOf(row.get("category"));
                String description = String.valueOf(row.get("description"));
                boolean implemented = "implemented".equals(row.get("state"));
                MODULES.add(new ClientModule(id, name, category, description, implemented));
            }
        } catch (Exception e) {
            throw new IllegalStateException("Could not load module catalog", e);
        }
    }

    public static List<ClientModule> all() {
        return Collections.unmodifiableList(MODULES);
    }

    public static List<ClientModule> inCategory(String category) {
        return MODULES.stream().filter(m -> m.category().equals(category)).toList();
    }

    public static void onStateChanged(ClientModule module) {
        ClientConfig.save();
        ClientFeatures.onModuleChanged(module);
    }

    public static Optional<ClientModule> byId(String id) {
        return MODULES.stream().filter(m -> m.id().equals(id)).findFirst();
    }
}
