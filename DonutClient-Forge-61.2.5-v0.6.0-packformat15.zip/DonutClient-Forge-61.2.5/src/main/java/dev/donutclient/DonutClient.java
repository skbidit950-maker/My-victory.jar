package dev.donutclient;

import net.minecraftforge.fml.common.Mod;

@Mod(DonutClient.MOD_ID)
public final class DonutClient {
    public static final String MOD_ID = "donutclient";

    public DonutClient() {
        ModuleRegistry.loadCatalog();
        ClientConfig.load();
    }
}
