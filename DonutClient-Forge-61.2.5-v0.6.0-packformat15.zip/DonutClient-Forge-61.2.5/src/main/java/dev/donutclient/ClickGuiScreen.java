package dev.donutclient;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;

public final class ClickGuiScreen extends Screen {
    private static final int PANEL_X = 24;
    private static final int PANEL_Y = 24;
    private static final int PANEL_W = 360;
    private static final int ROW_H = 22;
    private int scroll;

    public ClickGuiScreen() {
        super(Component.literal("DonutClient"));
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g, mouseX, mouseY, partialTick);
        int x2 = PANEL_X + PANEL_W;
        int y2 = Math.min(height - 20, PANEL_Y + 48 + ModuleRegistry.all().size() * ROW_H);
        g.fill(PANEL_X, PANEL_Y, x2, Math.max(PANEL_Y + 100, y2), 0xE9151820);
        g.fill(PANEL_X, PANEL_Y, x2, PANEL_Y + 28, 0xFF273449);
        g.drawString(font, "DONUTCLIENT  |  " + ModuleRegistry.all().size() + " MODULES",
                PANEL_X + 10, PANEL_Y + 10, 0xFFFFFFFF, false);
        g.drawString(font, "Green = implemented   Gray = catalog/backlog",
                PANEL_X + 10, PANEL_Y + 34, 0xFFB8C4D8, false);

        int start = Math.max(0, scroll);
        int visible = Math.max(1, (height - PANEL_Y - 58) / ROW_H);
        List<ClientModule> modules = ModuleRegistry.all();
        for (int i = start; i < Math.min(modules.size(), start + visible); i++) {
            ClientModule m = modules.get(i);
            int y = PANEL_Y + 54 + (i - start) * ROW_H;
            int bg = m.implemented() ? (m.enabled() ? 0xFF244D3C : 0xFF202A35) : 0xFF303039;
            g.fill(PANEL_X + 6, y, x2 - 6, y + ROW_H - 2, bg);
            String status = m.implemented() ? (m.enabled() ? "ON" : "OFF") : "PLANNED";
            g.drawString(font, m.category() + "  /  " + m.name(),
                    PANEL_X + 12, y + 6, m.implemented() ? 0xFFE8EDF5 : 0xFF969AA3, false);
            int sw = font.width(status);
            g.drawString(font, status, x2 - 14 - sw, y + 6,
                    m.implemented() ? 0xFFB8F2C9 : 0xFFB0B0B0, false);
        }
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 && mouseX >= PANEL_X && mouseX <= PANEL_X + PANEL_W
                && mouseY >= PANEL_Y + 54) {
            int row = (int) ((mouseY - (PANEL_Y + 54)) / ROW_H);
            int index = scroll + row;
            if (index >= 0 && index < ModuleRegistry.all().size()) {
                ModuleRegistry.all().get(index).toggle();
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        int max = Math.max(0, ModuleRegistry.all().size() -
                Math.max(1, (height - PANEL_Y - 58) / ROW_H));
        scroll = Math.max(0, Math.min(max, scroll - (int) Math.signum(delta) * 3));
        return true;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
