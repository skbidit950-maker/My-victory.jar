package dev.donutclient;

public final class ClientModule {
    private final String id;
    private final String name;
    private final String category;
    private final String description;
    private final boolean implemented;
    private boolean enabled;

    public ClientModule(String id, String name, String category, String description, boolean implemented) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.description = description;
        this.implemented = implemented;
    }

    public String id() { return id; }
    public String name() { return name; }
    public String category() { return category; }
    public String description() { return description; }
    public boolean implemented() { return implemented; }
    public boolean enabled() { return enabled; }

    public void setEnabled(boolean value) {
        if (!implemented) return;
        enabled = value;
        ModuleRegistry.onStateChanged(this);
    }

    public void toggle() {
        if (implemented) setEnabled(!enabled);
    }
}
